
This is just a collection of simple macros, 
not a real class with a stream as param 
(todo someday somewhere)
