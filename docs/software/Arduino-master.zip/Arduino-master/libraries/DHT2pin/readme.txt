
NOTE: THIS LIB IS NOT TESTED EXTENSIVELY YET SO ALL DISCLAIMERS APPLY

This library is an experimental version of the DHT library that uses 2 pins instead of 3.
One pin for all read actions and one pin for write actions.

It was made after a request which also refered to the links below.

https://communities.intel.com/thread/53869
http://bigdinotech.com/tutorials/galileo-tutorials/using-1-wire-device-with-intel-galileo/

NOTE: THIS LIB IS NOT TESTED EXTENSIVELY YET SO ALL DISCLAIMERS APPLY

